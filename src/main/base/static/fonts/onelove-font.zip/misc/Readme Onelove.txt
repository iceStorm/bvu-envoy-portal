Hello,

Thank for downloading Onelove



NOTE: This demo font is for PERSONAL USE ONLY! 


Link to purchase full version and commercial license:
https://fontbundles.net/abodaniel92/258160-onelove



If there is a problem, question, or anything about my fonts, please sent an email to

panggahlaksono@gmail.com




Thanks,


ABODNYL